<?php 
header("Location: https://www.bestrealdoll.com?sca_ref=8387003.L59QL5FKTp"); 
exit;
?>
