<?php 

header("Location: https://www.kupid.ai/create-ai-girlfriend?src_ref=0aff9070c&sub_id=girlgs"); 

exit;
?>
